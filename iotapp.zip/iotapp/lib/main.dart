import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: MyHomePage(),
    );
  }
}


class MyHomePage extends StatefulWidget {
  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  String message = 'Not connected';

  void controlLED(String ipAddress, bool turnOn) async {
    try {
      final response = await http.get(Uri.parse(
          'http://$ipAddress/ledControl?status=${turnOn ? "1" : "0"}'));

      if (response.statusCode == 200) {
        setState(() {
          message = 'LED ${turnOn ? "On" : "Off"}';
        });
      } else {
        setState(() {
          message = 'Failed to control LED';
        });
      }
    } catch (e) {
      setState(() {
        message = 'Failed to control LED';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Simple LED Control'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text(
              'Status: $message',
              style: TextStyle(fontSize: 20),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                // Replace '192.168.1.2' with your NodeMCU IP address
                controlLED('192.168.43.51', true);
              },
              child: Text('Turn On LED'),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                // Replace '192.168.1.2' with your NodeMCU IP address
                controlLED('192.168.43.51', false);
              },
              child: Text('Turn Off LED'),
            ),
          ],
        ),
      ),
    );
  }
}
